function hide(a1,b1,c1)
    {
    document.getElementById(a1).style.display="none";
    document.getElementById(b1).style.display="none";
    document.getElementById(c1).style.display=""
       
    } 
 function show(a1)
 {
 	var x = document.getElementsByClassName(a1);
 	var i;
for (i = 0; i < x.length; i++) {
    x[i].style.display = "";
}
   
 }
  function hides(a1)
 {
 	var x = document.getElementsByClassName(a1);
 	var i;
for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
}
   
 }
 function getAll(a1,a2)
 {
    var hi=document.getElementById('flag_show').innerHTML;
    if(hi==0)
    {	
	var x = document.getElementsByClassName(a1);
    var y=document.getElementsByClassName(a2);

 	var i;
    for (i = 0; i < x.length; i++) {
    x[i].style.display = "";
    y[i].style.display="";
    }
    document.getElementById('flag_show').innerText=1;
    }
    else{
    var x = document.getElementsByClassName(a1);
    var y=document.getElementsByClassName(a2);
 	var i;
    for (i = 0; i < x.length; i++) {
    x[i].style.display = 'none';
    y[i].style.display='none';
}
    document.getElementById('flag_show').innerText=0;
    }
    
 }