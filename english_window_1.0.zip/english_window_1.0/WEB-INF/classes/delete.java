package english;
import java.io.*;
public class delete{
	public static void delete(String path)
	{
		File f=new File(path);
		boolean result=f.delete();
		if (!result) {
            System.gc();    
            f.delete();
        }
	}
}