package english;
import java.io.File;
import java.io.FileOutputStream;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

public class dom {
  public static void addxml(String tran_word,String tran_translate,String tran_title,String path)throws Exception
  {
	  SAXReader saxReader=new SAXReader();
	  Document doc=saxReader.read(new File(path));
	  Element root = doc.getRootElement();
	 
	
	 Element words=root.addElement("words");
	  
	  Element word=words.addElement("word");
	  Element translate=words.addElement("translate");
	  Element title=words.addElement("title");
	  word.setText(tran_word);
	  translate.setText(tran_translate);
	  title.setText(tran_title);
	  OutputFormat format=OutputFormat.createPrettyPrint();
	  format.setEncoding("utf-8");
	  XMLWriter writer=new XMLWriter(new FileOutputStream(new File(path)),format);
	  writer.write(doc);
	  writer.close();
  }
  public static void buildxml(String path)throws Exception
  {
	  Document doc=DocumentHelper.createDocument();
	  Element wordlist=doc.addElement("wordlist");
	  //wordlist.setText("");
	  OutputFormat format=OutputFormat.createPrettyPrint();
	  format.setEncoding("utf-8");
	  XMLWriter writer=new XMLWriter(new FileOutputStream(new File(path)),format);
	  writer.write(doc);
	  writer.close();
  }
  public static boolean isexist(String path)throws Exception
  {
	 
	  File f=new File(path);
	  return f.exists();
	  
  }
}
