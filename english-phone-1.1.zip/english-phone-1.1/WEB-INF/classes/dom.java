package english;
import java.io.File;
import java.io.FileOutputStream;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import java.util.*;

public class dom {
  public static void copy(String old,String newpath)throws Exception
  {
	  File oldf=new File(old);
	  newpath=think(newpath);
	  buildxml(newpath);
	  SAXReader reader=new SAXReader();
	  Document doc=reader.read(oldf);
	  Element root=doc.getRootElement();
	  Iterator iter=root.elementIterator();
	  while(iter.hasNext())
	  {
		  Element words=(Element)iter.next();
		  addxml(words.elementText("word"),words.elementText("translate"),words.elementText("title"),newpath);
	  }
	  
	  
  }
  
  public static void addxml(String tran_word,String tran_translate,String tran_title,String path)throws Exception
  {
	  SAXReader saxReader=new SAXReader();
	  Document doc=saxReader.read(new File(path));
	  Element root = doc.getRootElement();
	  //System.out.println(root.getName());
	
	  Element words=root.addElement("words");
	  
	  Element word=words.addElement("word");
	  Element translate=words.addElement("translate");
	  Element title=words.addElement("title");
	  word.setText(tran_word);
	  translate.setText(tran_translate);
	  title.setText(tran_title);
	  OutputFormat format=OutputFormat.createPrettyPrint();
	  format.setEncoding("utf-8");
	  XMLWriter writer=new XMLWriter(new FileOutputStream(new File(path)),format);
	  writer.write(doc);
	  writer.close();
  }
  
  public static void buildxml(String path)throws Exception
  {
	  Document doc=DocumentHelper.createDocument();
	  Element wordlist=doc.addElement("wordlist");
	  //wordlist.setText("");
	  OutputFormat format=OutputFormat.createPrettyPrint();
	  format.setEncoding("utf-8");
	  XMLWriter writer=new XMLWriter(new FileOutputStream(new File(path)),format);
	  writer.write(doc);
	  writer.close();
  }
  
  public static boolean isexist(String path)throws Exception
  {
	 
	  File f=new File(path);
	  return f.exists();
	  
  }
  public static String think(String path)
	{
		
		File f=new File(path);
		int i=1;
		if(f.exists())
		{	
		while(f.exists())
		{
			f=new File(path.substring(0,path.length()-4)+(i)+".xml");
			i++;
		}
		path=path.substring(0,path.length()-4)+(i-1)+".xml";
        return path;
	    }
	    else{
	    	return path;
		
	    }

	}
}
