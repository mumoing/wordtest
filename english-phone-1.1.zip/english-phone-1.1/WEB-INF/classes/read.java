package english;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import java.sql.*;

public class read {
	public static final String dbuser="root";
	public static final String dbpass="jizhen";
	public static final String dburl="jdbc:mysql://localhost:3306/word";
	public static final String dbdriver="org.gjt.mm.mysql.Driver";

public static void write(String readpath,String writepath,String title)throws Exception
{
	//String path="S:"+File.separator+"englishs"+File.separator+"upload"+File.separator+"新课标a.txt";
	//String pathwrite="S:"+File.separator+"englishs"+File.separator+"xml"+File.separator+"新课标a.xml";
	File f=new File(readpath);
	//File fwrite=new File(writepath);
	//Writer out=new FileWriter(fwrite,false);
	FileOutputStream fwrite = new FileOutputStream(writepath,false);   
	OutputStreamWriter out = new OutputStreamWriter(fwrite, "UTF-8"); 
	out.write("<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"no\"?><wordlist>");
	out.close();
	//Writer out1=new FileWriter(fwrite,true);
	FileOutputStream fwrite1 = new FileOutputStream(writepath,true); 
	OutputStreamWriter out1 = new OutputStreamWriter(fwrite1, "UTF-8");
    FileInputStream input=new FileInputStream(f);
    BufferedReader bufr = new BufferedReader(new InputStreamReader(input,"utf-8"));
    String line=null;
    String translate=null;
    while((line=bufr.readLine())!=null){
    translate=getTranslate(line);
   // System.out.println(line+"  "+translate);
    insert(line,translate,title);
    out1.write("<words><word>"+line+"</word><translate>"+translate+"</translate><title>"+title+"</title></words>");
    }
    out1.write("</wordlist>");
    
    bufr.close();
    out1.close();
}
public static String getTranslate(String word)throws Exception
{
	word=word.replaceAll(" ", "+");
	String url="http://m.youdao.com/dict?le=eng&q="+word;
	CloseableHttpClient client=HttpClients.createDefault(); //创建一个可关闭的客户端
	HttpGet hp=new HttpGet(url);//创建post方法
	//设置头信息
	hp.setHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
	hp.setHeader("Accept-Encoding", "gzip, deflate");
	hp.setHeader("Accept-Language","zh-cn");
	hp.setHeader("Connection","keep-alive");
	hp.setHeader("Cookie","___rl__test__cookies=1526297207528; JSESSIONID=abc8T9npcpuvChUlnzEnw; _yd_newbanner_day=14; OUTFOX_SEARCH_USER_ID_NCOO=1006420317.710858; OUTFOX_SEARCH_USER_ID=1297994902@220.180.56.52");
	hp.setHeader("Host","m.youdao.com");
	hp.setHeader("Referer","http://m.youdao.com");
	hp.setHeader("Upgrade-Insecure-Requests","1");
	hp.setHeader("User-Agent","Mozilla/5.0 (iPhone; CPU iPhone OS 11_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.0 Mobile/15E148 Safari/604.1");
	CloseableHttpResponse response=client.execute(hp);
	HttpEntity entity = response.getEntity();
	String web= EntityUtils.toString(entity,"UTF-8");
	//System.out.println(web);
	int i=web.indexOf("该词条暂未被收录");
	if(i==-1)
	{
	Document doc=Jsoup.parse(web,"utf-8");
	Elements con=doc.getElementsByTag("ul");
	
		
		return con.get(2).text();
	}else{
		return "该词条暂未被收录";
		
	}
}
public static void insert(String word,String translate,String title)throws Exception
{

	Class.forName(dbdriver);
	Connection conn=DriverManager.getConnection(dburl,dbuser,dbpass);
	String sql="INSERT INTO list VALUES(?,?,?)";
	PreparedStatement pstmt=conn.prepareStatement(sql);
	pstmt.setString(1, word);
	pstmt.setString(2, translate);
	pstmt.setString(3, title);
    pstmt.executeUpdate();
    pstmt.close();
    conn.close();

	
	
	
}
}