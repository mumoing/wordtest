package english;
import java.io.File;
public class rename{
	public static void rename(String path,String newname,String oldname)
	{
		File file=new File(path+File.separator+oldname);
		File files=new File(path+File.separator+newname);
		file.renameTo(files);
	}
	public static void build(String path)
	{
		File f=new File(path);
		f.mkdir();
	}
}