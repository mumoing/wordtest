//随机的背诵列表
function random(path)
{
var doc = loadXMLDoc(path);
var word=doc.getElementsByTagName("word");
var translate=doc.getElementsByTagName("translate");

var order=getOrder(0,word.length-1);
document.write("<table border=\"3\">");
for(i=0;i<word.length;i++)
{   
	document.write("<tr>");
	document.write("<td class=\"word\" >");
	document.write(word[order[i]].childNodes[0].nodeValue);
	document.write("</td>");
	document.write("<td class=\"translate\">");
	document.write(translate[order[i]].childNodes[0].nodeValue);
	document.write("</td>");
    document.write("</tr>");
}
document.write("</table>");
}
//顺序的背诵列表
function order(path)
{
var doc = loadXMLDoc(path);
var word=doc.getElementsByTagName("word");
var translate=doc.getElementsByTagName("translate");
var biao=doc.getElementsByTagName("biao");
var order=getOrder(0,word.length-1);
	document.write("<table id=\"order\" border=\"3\">");
for(i=0;i<word.length;i++)
{   

	document.write("<tr>");

	document.write("<td class=\"word\" >");
	document.write("<b>"+word[i].childNodes[0].nodeValue+"</b>");
	document.write("</td>");

	document.write("<td class=\"biao\">")
	document.write(biao[i].childNodes[0].nodeValue);
	document.write("<td>");
	
	document.write("<td class=\"translate\">");
	document.write(translate[i].childNodes[0].nodeValue);
	document.write("</td>");
    document.write("</tr>");
}
document.write("</table>");
}
function response(hi)
{
	alert(hi);
}
//翻译的测试列表
function transtest(path)
{
	
var doc = loadXMLDoc(path);
var word=doc.getElementsByTagName("word");
var translate=doc.getElementsByTagName("translate");

var order=getOrder(0,word.length-1);
indexof = function(value) {
        var a = order;//为了增加方法扩展适应性。我这稍微修改了下
        for (var i = 0; i < a.length; i++) {
            if (a[i] == value)
                return i;
        }
    }

document.write("<table id=\"trans_test\" border=\"3\">");
var trueword;
for(i=0;i<word.length;i++)
{   trueword=word[order[i]].childNodes[0].nodeValue;
	truetrans=translate[order[i]].childNodes[0].nodeValue;
    
	document.write("<tr>");
	document.write("<td class=\"word\" >");
    //document.write("<a href=\"javascript:void(0)\" onclick=\"alert(getTranslate(this.innerHTML,'"+path+"'));return false;\" title=i>");
    document.write("<a class=\"wording\" href=\"javascript:void(0)\" onclick=\"alertify.confirm('答案', getTranslate(this.innerHTML,'"+path+"'), function(){alertify.set('notifier','delay', 1),alertify.set('notifier','position', 'top-center'),alertify.success('已操作'),changecolor_word(indexof(i))}, function(){}).set( 'labels', {ok:'收藏|取消收藏', cancel:'关闭'}).moveTo(0,150);return false;\" title=i>");
	document.write(trueword);
	document.write("</a>");
	document.write("</td>");
	document.write("<td class=\"hide_test_trans\" style=\"display:none;\" >");
	document.write(translate[order[i]].childNodes[0].nodeValue);
	document.write("</td>");
    document.write("</tr>");
}
document.write("</table>");

}
//拼写的测试列表
function wordtest(path)
{

var doc = loadXMLDoc(path);
var word=doc.getElementsByTagName("word");
var translate=doc.getElementsByTagName("translate");

var order=getOrder(0,word.length-1);
indexof_trans=function(value) {
        var a = order;
        for (var i = 0; i < a.length; i++) {
            if (a[i] == value)
                return i;
        }
    }
document.write("<table id=\"word_test\" border=\"3\">");
var trueword;
for(i=0;i<word.length;i++)
{   trueword=word[order[i]].childNodes[0].nodeValue;
	truetrans=translate[order[i]].childNodes[0].nodeValue;
	
	document.write("<tr>");
	document.write("<td class=\"translate\" >");
    //document.write("<a href=\"javascript:void(0)\" onclick=\"alert(getWord(this.innerHTML,'"+path+"'));return false;\" title=i>");
    document.write("<a class=\"transing\" href=\"javascript:void(0)\" onclick=\"alertify.confirm('答案', getWord(this.innerHTML,'"+path+"'), function(){alertify.set('notifier','delay', 1),alertify.set('notifier','position', 'top-center'),alertify.success('已操作'),changecolor_trans(indexof_trans(i))}, function(){}).set( 'labels', {ok:'收藏|取消收藏', cancel:'关闭'}).moveTo(0,150);return false;\" title=i>");	 
	document.write(truetrans);
	document.write("</a>");
	document.write("</td>");
	document.write("<td class=\"hide_test_word\" style=\"display:none;\" >");
	document.write(word[order[i]].childNodes[0].nodeValue);
	document.write("</td>");
    document.write("</tr>");
}
document.write("</table>");
}
//通过单词获取含义
function getTranslate(words,path)
{
var doc = loadXMLDoc(path);
var word=doc.getElementsByTagName("word");
var translate=doc.getElementsByTagName("translate");
var order=getOrder(0,word.length-1);
for(i=0;i<word.length;i++)
{   
	word1=word[i].childNodes[0].nodeValue;
	if(word1==words)
	{
		return translate[i].childNodes[0].nodeValue
	}
}

return words;

}
//通过点击获取音标
//
//
//通过翻译获取单词拼写
function getWord(words,path)
{
  var doc = loadXMLDoc(path);
var word=doc.getElementsByTagName("word");
var translate=doc.getElementsByTagName("translate");

var order=getOrder(0,word.length-1);
	
for(i=0;i<word.length;i++)
{   
	word1=translate[i].childNodes[0].nodeValue;
	if(word1==words)
	{
		return word[i].childNodes[0].nodeValue;
	}
}

}
function change0()
{
	document.getElementById('flag').innerText=0;
	//flag=0;
}
function change1()
{
	document.getElementById('flag').innerText=1;
	//flag=1;
}
function change2()
{
	document.getElementById('flag').innerText=2;
	//flag=2;
}
function getRandom()
{
	flaging=document.getElementById('flag').innerHTML;
	window.location.href='hi.jsp?title='+titles+'&flag='+flaging+'';
}
function amount(path)
{

var doc = loadXMLDoc(path);
var word=doc.getElementsByTagName("word");
document.getElementById('amount').innerText="词汇量:"+word.length;
}

function changecolor_word(ai){
	
	//document.getElementById('a1').style.color=red
	//alert(a1);
	var end=document.getElementsByClassName('wording');

	var val=end[ai].style.color;

	if ( val== 'red') 
	{
	end[ai].style.color = "";
	end[ai].style.fontWeight='';
	} 
	else {
		end[ai].style.color = "red";
	    end[ai].style.fontWeight='bold';
	}
	
}
function changecolor_trans(ai){
	
	//document.getElementById('a1').style.color=red
	//alert(a1);
	var end=document.getElementsByClassName('transing');
	var val=end[ai].style.color;

	if ( val== 'red') 
	{
	end[ai].style.color = "";
	end[ai].style.fontWeight='';
	} 
	else {
		end[ai].style.color = "red";
	    end[ai].style.fontWeight='bold';
	}
}
function question()
{
	flagnum=document.getElementById('flag').innerHTML;
	if(flagnum==2)
	{
    alertify.prompt( '将收藏的单词提取出来形成新的词库(注意：输入的文件名不要与词库中存在的文件名重复,否则两者将被合并)','输入收藏文件名', question_title+"_收藏_翻译测试"
               , function(evt, value) { getKeep(value) }
               , function() { });
    }
    else{
    	if(flagnum==1)
    	{
           alertify.prompt('将收藏的单词提取出来形成新的词库(注意：输入的文件名不要与词库中存在的文件名重复,否则两者将被合并)','输入收藏文件名', question_title+"_收藏_拼写测试"
               , function(evt, value) { getKeep(value) }
               , function() { });
        }
         else
         {
           alertify.set('notifier','delay', 2),alertify.set('notifier','position', 'top-center'),alertify.success('背诵模式无法进行收藏操作！');
         }
     }
}

function getKeep(title)
{
	flagnum=document.getElementById('flag').innerHTML;
	if (flagnum==2)
	 {  var flag_not_exist=true;
	 	//var doc = loadXMLDoc('/xml/ying/hi_翻译_收藏1.xml');
	 	var lists_word =document.getElementsByClassName('wording');
	 	var lists_trans=document.getElementsByClassName('hide_test_trans');
	 	for(i=0;i<lists_word.length;i++)
	 	{
	 		var font_color=lists_word[i].style.color;
	 		if(font_color=='red')
	 		{
	 			flag_not_exist=false;
	 			var one_word=lists_word[i].innerHTML;
	 			var one_trans=lists_trans[i].innerHTML;
                var keeppath=document.getElementById('path').innerHTML+title+".xml";
                //alert(keeppath);
	 			//alert(one_word);
	 			//alert(one_trans);
	 			$.ajaxSetup({async: false});//务必进行同步处理否则 得到的xml将可能不再完整
	 			$.post("buildxml.jsp", { "word": one_word,"trans":one_trans,"path":keeppath,"title":title}, function(data){}, "json");
	 			//alert(one_trans);
	 			//alert("成功");
	 		}
	 	}
	 		if(flag_not_exist)
	 	{
          alertify.set('notifier','delay', 2),alertify.set('notifier','position', 'top-center'),alertify.success('无收藏的词汇！无法进行保存！')
	 	}
	 }
	else
	 {
//直接从翻译测试那个if复制了过来 就改了类的获取。
        var flag_not_exist=true;
        var lists_word =document.getElementsByClassName('transing');
	 	var lists_trans=document.getElementsByClassName('hide_test_word');
	 	for(i=0;i<lists_word.length;i++)
	 	{
	 		var font_color=lists_word[i].style.color;
	 		if(font_color=='red')
	 		{
	 			flag_not_exist=false;
	 			var one_word=lists_word[i].innerHTML;
	 			var one_trans=lists_trans[i].innerHTML;
                var keeppath=document.getElementById('path').innerHTML+title+".xml";
                //alert(keeppath);
	 			//alert(one_word);
	 			//alert(one_trans);
	 			$.ajaxSetup({async: false});
	 			$.post("buildxml.jsp", { "word": one_trans,"trans":one_word,"path":keeppath,"title":title}, function(data){}, "json");
	 			//alert(one_trans);
	 			//alert("成功");
	 		}
	 	}
	 	if(flag_not_exist)
	 	{
          alertify.set('notifier','delay', 2),alertify.set('notifier','position', 'top-center'),alertify.success('无收藏的词汇！无法进行保存！')
	 	}


	 }
}