function loadXMLDoc(dname) 
{
  /*
try //Internet Explorer

  {
  xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
  }
catch(e)
  {
  try //Firefox, Mozilla, Opera, etc.
    {
    xmlDoc=document.implementation.createDocument("","",null);
    }
  catch(e) {alert(e.message)}
  }
try 
  {
  xmlDoc.async=false;
  xmlDoc.load(dname);
  return(xmlDoc);
  }
catch(e) {alert(e.message)}
return(null);*/

var xmlDom = null;    
      if (window.ActiveXObject){    
        xmlDom = new ActiveXObject("Microsoft.XMLDOM");    
        xmlDom.async=false;    
       xmlDom.load(dname)||xmlDom.loadXML(dname);//如果用的是XML字符串//如果用的是xml文件    
      }else if (document.implementation && document.implementation.createDocument){    
        var xmlhttp = new window.XMLHttpRequest();    
        xmlhttp.open("GET", dname, false);    
        xmlhttp.send(null);    
        xmlDom = xmlhttp.responseXML;    
      }else{    
        xmlDom = null;    
      }    
      return xmlDom; 
        
  
    
}
function getOrder(start, end) {  
               var length = end - start;  
               var myorder = new Array();  
               var index = 0;  
               while (index < length+1) {  
                   var flag = true;  
                   var num = parseInt(Math.random() * (length + 1));  
                   for (var i in myorder) {  
                       if (myorder[i] == num) {  
                           flag = false;  
                       }  
                   }  
                   if (flag == true) {  
                       myorder[index] = num;  
                       index++;  
                   }  
               }  
               //document.write(myorder.length); 
               //document.write("<br>") ;
               //document.write(myorder);
               return myorder;  
 } 