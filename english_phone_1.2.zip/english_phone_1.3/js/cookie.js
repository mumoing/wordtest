function getCookie(cname)
{
var name = cname + "=";
var ca = document.cookie.split(';');
for(var i=0; i<ca.length; i++)
  {
  var c = ca[i].trim();
  if (c.indexOf(name)==0) return c.substring(name.length,c.length);
  }
return "";
}
function checkCookie()
{
var username=getCookie("recode");
if (username!="")
  {
  //into();
  alert("欢迎回来！")
  }
else
  {
 //alert("你没有权限使用,如需获取权限请联系qq：1432540191");
 window.location.href="login.jsp";
  }
}

function checkform(the) {
		var hi=document.getElementById('file_name').value;
		hi=hi.substring(hi.length-4,hi.length); 
		if (hi=='.txt') 
		{
		 var upload_button=document.getElementById('upload');
		 upload_button.value='上传中';
		 upload_button.disabled=true;
		 alertify.set('notifier','delay', 600);
		 alertify.set('notifier','position', 'bottom-center');
         alertify.success('上传中...');
         return true;
		}
		 else {
		 alertify.set('notifier','delay', 3);
		 alertify.set('notifier','position', 'top-center');
         alertify.success('只允许上传.txt格式的文件');
         return false;
		 }
	}

function to_public()
{
  window.location.href="public.jsp";
}