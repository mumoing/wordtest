package english;
import java.io.File;

public class find {

	public static String findlist(String path)
	{
		File f=new File(path);
		String str[]=f.list();
		
		String result="";
		for(int i=0;i<str.length;i++)
		{
			result=result+str[i]+"***";
			
		}
		return result;
	}

}