package english;
import java.sql.* ;
import java.io.* ;
import javax.servlet.* ;
import javax.servlet.http.* ;
import java.io.*;
public class check extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
		this.doPost(request,response) ;
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
		request.setCharacterEncoding("utf-8") ;
		response.setContentType("text/html") ;
		PrintWriter out = response.getWriter() ;
		String userid = request.getParameter("userid") ;
		userid=File.separator+"home"+File.separator+"web"+File.separator+"englishs"+File.separator+"upload"+File.separator+userid;
		File f=new File(userid);
		if(f.exists())
        {
		out.print("false") ;
		} else {
		out.print("true") ;
	    }
}
}